from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Trip, TripManager, User, UserManager
from datetime import datetime

# Create your views here.

def welcome(request):
    if not 'user_id' in request.session:
        message.add_messgae(request, message.INFO, "Please make an account or register first", extra_tags = 'login')
        return redirect ('/')
    context = {
        'trips': User.objects.get(id=request.session['user_id']).trips.all(),
        'all_trips': Trip.objects.exclude(users = request.session['user_id'])
    }
    return render (rquest, 'trip/welcome.html', context)

def add(request):
    if not 'user_id' in request.session:
        message.add_messgae(request, message.INFO, "Please make an account or register first", extra_tags = 'login')
        return redirect ('/')
    return render (request, 'trip/add.html')

def adding(request):
    errors = Trip.objects.trip_validator(request.POST)
    if len(errors):
        for tag,error in errors.items():
            messages.error(request, error, extra_tag=tag)
        return redirect ('/add')
    else:
        person = User.objects.get(id=request.session['user_id'])
        person.save()
        trip = Trip.objects.create(destination = request.POST['destination'], description = request.POST['description'], start_date = request.POST['start_date'], end_date = request.POST['end_date'])
        trip.save()
        trip.users.add(person)
        trip.save()
        return redirect('/')

def destination(request, number):
    if not 'user_id' in request.session:
        message.add_messgae(request, message.INFO, "Please make an account or register first", extra_tags = 'login')
        return redirect ('/')
    trip = Trip.objects.get(id=number)
    context = {
        'destination': Trip.destination,
        'description': Trip.description,
        'start_date': Trip.start_date,
        'end_date': Trip.end_date,
        'creator': Trip.users.first(),
        'all_users': Trip.users.all(),
    }
    return render (request, 'trip/destination.html', context)

def join(request, number):
    trip = Trip.objects.get(id=number)
    trip.save()
    newuser = User.objects.get(id=request.session['user_id'])
    newuser.save()
    trip.users.add(newuser)
    return redirect ('/')

def leave(request, number):
    trip = Trip.objects.get(id=number)
    trip.save()
    user = User.objects.get(id=request.session['user_id'])
    user.save()
    trip.users.remove(user)
    if not trip.users.all():
        trip.delete()
    return redirect ('/')

def delete(request, number):
    trip = Trip.objects.get(id=number)
    trip.delete()
    return redirect ('/')