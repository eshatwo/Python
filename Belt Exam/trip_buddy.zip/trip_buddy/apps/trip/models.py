from django.db import models
from ..user.models import User, UserManager
import re
import bcrypt
from datetime import datetime

# Create your models here.
class TripManager(models.Manager):
    def trip_validator(self, postData):
        errors ={}
        if len(postData['destination']) < 1:
            errors['destination_len'] = "Please enter a destination"
        if len(postData['description']) < 1:
            errors['description_len'] = "Please enter a description"
        if len(postData['start_date']) < 1:
            errors['start_date_len'] = "Please enter a start date"
        if len(postData['end_date']) < 1:
            errors['end_date_len'] = "Please enter an end date"
        # elif postData['end_date'] < str(datetime.now()):
        #     errors['future'] = "End date must be in the future"
        # if postData['start_date'] > postData['end_date']:
        #     errors['date_error'] = "Start date must be before the end date"
        return errors

class Trip(models.Model):
    destination = models.CharField(max_length = 255)
    description = models.TextField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    users = models.ManyToManyField(User, related_name = "trips")
    objects = TripManager()