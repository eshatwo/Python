from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.welcome),
    url(r'^add$', views.add),
    url(r'^adding$', views.adding),
    url(r'^destination/(?P<number>\d+)$', views.destination),
    url(r'^join/(?P<number>\d+)$', views.join),
    url(r'^leave/(?P<number>\d+)$', views.leave),
    url(r'^delete/(?P<number>\d+)$', views.delete),
]