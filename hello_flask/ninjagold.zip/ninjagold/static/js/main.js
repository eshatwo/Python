$(document).ready(function () {
    
    $("#activities").scrollTop($("#activities")[0].scrollHeight);

});